# Multi-Robot SLAM, Autonomous Exploration & Map Merging

**Submission Details:**
- **Participant Roll Number:** `<rollno>`
- **First Name:** `<firstname>`
- **ROS 2 Distribution:** ROS 2 Humble Hawksbill
- **Simulator:** Gazebo Classic 11
- **Platform:** Ubuntu 22.04 LTS
- **Demonstration Video:** `demo_video.webm` (included directly in this directory)

---

## 1. Project Overview

This project implements an autonomous multi-robot SLAM, exploration, and occupancy grid merging system for two TurtleBot3 robots deployed in an unknown, enclosed Gazebo arena. The two robots operate completely independently in separated namespaces (`/robot1` and `/robot2`), build local occupancy grid maps using their onboard 2D LiDAR sensors and wheel odometry, detect frontiers to steer navigation autonomously using Nav2, and continuously fuse their local maps into a unified global map. Once all reachable frontiers are explored, the robots stop moving autonomously and output the completed map files to disk.

---

## 2. Package Architecture (`/src`)

The repository source code contains modular packages structured to satisfy the architecture requirements:

| Package | Role | Description |
| :--- | :--- | :--- |
| **`simulation`** | Gazebo Arena & Spawning | Launches Gazebo with the maze world, manages robot SDF definitions, and spawns robots with isolated frame prefixes (`robot1/`, `robot2/`). |
| **`robot_slam`** | Dual SLAM Pipeline | Runs independent instances of `slam_toolbox` under isolated namespaces (`robot1` and `robot2`) publishing local maps on `/robot1/map` and `/robot2/map`. |
| **`navigation`** | Nav2 Navigation Stack | Configures dual Nav2 planners, pure pursuit controllers, and costmaps with global TF consistency. |
| **`exploration`** | Frontier Exploration | Frontier-based exploration nodes detecting boundary cells between free and unknown space and dispatching goals via Nav2 action servers. |
| **`explore_lite`** | Frontier Exploration Stack | High-performance C++ Yamauchi frontier explorer with frontier blacklist tracking, goal preemption safeguards, and footprint inflation filtering. |
| **`map_merger`** | Occupancy Grid Stitcher | Dynamic grid fusion node computing bounding boxes, prioritizing occupied obstacles, and broadcasting global transforms. |
| **`multirobot_map_merge`** | Multi-Robot Map Merging | Real-time Hough transform and initial-pose map merging node stitching local grids into `/map` on frame `world`. |
| **`bringup`** | Master Orchestration | Single-command master bringup launch files and unified RViz2 visualization configurations. |
| **`explore_lite_msgs`** | Message Definitions | Service and action definitions supporting the exploration stack. |

---

## 3. Technical Approach

### 3.1 SLAM Pipeline
- **Decentralized Isolation:** Each robot runs an independent `slam_toolbox` node (`async_slam_toolbox_node` / `sync_slam_toolbox_node`) scoped to its own namespace.
- **Coordinate Frames:**
  - Robot 1: `robot1/map` $\rightarrow$ `robot1/odom` $\rightarrow$ `robot1/base_footprint`
  - Robot 2: `robot2/map` $\rightarrow$ `robot2/odom` $\rightarrow$ `robot2/base_footprint`
- **Transforms & Topics:** Laser scans (`/robot1/scan`, `/robot2/scan`) are processed independently with no cross-namespace topic or transform collisions.

### 3.2 Frontier Exploration Approach
- **Yamauchi Algorithm:** Boundaries between free space (cost 0) and unknown space (cost -1) in the local costmap are identified as candidate frontiers.
- **Connected Components & Clustering:** Contiguous frontier pixels are clustered to reject sensor noise and compute cluster centroids.
- **Reachable Goal Selection:** The closest valid, non-obstructed frontier centroid outside the robot's footprint inflation radius ($>0.35\,\text{m}$) is chosen as the navigation target.
- **Preemption Lock & Blacklisting:** Navigation goals run to completion without erratic oscillations. Visited or unreachable frontiers are added to a blacklist to ensure robots continually discover new territory.
- **Autonomous Termination:** When no reachable frontiers remain, both exploration nodes halt navigation, command zero velocity (`geometry_msgs/Twist`), and signal exploration completion.

### 3.3 Map Merging Approach
- **Grid Alignment & Registration:** Local occupancy grids published on `/robot1/map` and `/robot2/map` are received and aligned using known initial coordinate transforms into a common global reference frame (`world`).
- **Probabilistic Grid Blending:** Cell values are merged with precedence given to confirmed obstacles ($100$), followed by free space ($0$), preserving unknown areas ($-1$) until verified.
- **Unified Global Map:** The stitched occupancy grid is published on `/map` with `header.frame_id = world`.

---

## 4. How to Run

### Prerequisites
- Ubuntu 22.04 LTS with ROS 2 Humble Desktop
- TurtleBot3 Gazebo and Nav2 packages:
  ```bash
  sudo apt update
  sudo apt install ros-humble-turtlebot3* ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-slam-toolbox
  ```

### Build Instructions
Clone or copy the folder into a ROS 2 workspace, navigate to the workspace root containing `/src`, and build:

```bash
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
```

---

### Execution

#### Option 1: Master Single-Command Launch (Recommended)
Launch the complete multi-robot system (Gazebo simulation, dual SLAM, dual Nav2, map merging, exploration, RViz2 visualization, and completion monitor) with a single command:

```bash
export TURTLEBOT3_MODEL=waffle
export GAZEBO_MODEL_PATH=/opt/ros/humble/share/turtlebot3_gazebo/models:/usr/share/gazebo-11/models:$GAZEBO_MODEL_PATH
source /opt/ros/humble/setup.bash
source install/setup.bash

ros2 launch multirobot_map_merge launch_all_tasks.launch.py
```
*Note: To run headless or without RViz, append `use_rviz:=False`.*

#### Option 2: Modular Step-by-Step Bringup
Alternatively, launch each subsystem independently across separate terminals:

1. **Terminal 1 — Gazebo Simulation:**
   ```bash
   source install/setup.bash
   ros2 launch simulation simulation.launch.py
   ```
2. **Terminal 2 — Dual SLAM:**
   ```bash
   source install/setup.bash
   ros2 launch robot_slam dual_slam.launch.py
   ```
3. **Terminal 3 — Dual Nav2 Navigation:**
   ```bash
   source install/setup.bash
   ros2 launch navigation dual_navigation.launch.py
   ```
4. **Terminal 4 — Multi-Robot Map Merging:**
   ```bash
   source install/setup.bash
   ros2 launch multirobot_map_merge map_merge.launch.py
   ```
5. **Terminal 5 — Autonomous Frontier Exploration:**
   ```bash
   source install/setup.bash
   ros2 launch explore_lite dual_explore.launch.py
   ```
6. **Terminal 6 — RViz2 Visualization:**
   ```bash
   source install/setup.bash
   rviz2 -d install/multirobot_map_merge/share/multirobot_map_merge/launch/map_merge.rviz
   ```

---

## 5. System Verification

- **Active ROS 2 Topics:**
  ```bash
  ros2 topic list | grep -E "map|scan|cmd_vel"
  ```
- **Inspect Merged Global Map:**
  ```bash
  ros2 topic echo /map --no-arr --once
  ```
- **Inspect TF Coordinate Tree:**
  ```bash
  ros2 run tf2_tools view_frames
  ```
- **Completion Output:**
  When exploration completes, the system outputs the completion banner and saves the resulting occupancy grids (`merged_map.pgm/.yaml`, `robot1_map.pgm/.yaml`, `robot2_map.pgm/.yaml`) to disk.
