import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_map_merge = get_package_share_directory("multirobot_map_merge")
    pkg_explore = get_package_share_directory("explore_lite")

    simulator = LaunchConfiguration("simulator", default="gazebo")
    use_rviz = LaunchConfiguration("use_rviz", default="True")

    declare_simulator_cmd = DeclareLaunchArgument(
        "simulator",
        default_value="gazebo",
        description="The simulator to use (gazebo or gzserver)",
    )

    declare_use_rviz_cmd = DeclareLaunchArgument(
        "use_rviz",
        default_value="True",
        description="Whether to launch RViz",
    )

    # 1. Multi-robot simulation (Gazebo, dual robots, dual SLAM, dual Nav2)
    multi_tb3_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_map_merge, "launch", "tb3_simulation", "multi_tb3_simulation_launch.py")
        ),
        launch_arguments={
            "simulator": simulator,
            "use_rviz": "False",
            "slam_toolbox": "True",
            "slam_gmapping": "False",
        }.items()
    )

    # 2. Map Merger (delayed to allow SLAM maps to start publishing)
    map_merge_cmd = TimerAction(
        period=8.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_map_merge, "launch", "map_merge.launch.py")
                ),
                launch_arguments={
                    "known_init_poses": "True",
                    "use_sim_time": "True",
                }.items()
            )
        ]
    )

    # 3. Dual Exploration (delayed to ensure Nav2 action servers are fully active)
    dual_explore_cmd = TimerAction(
        period=14.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_explore, "launch", "dual_explore.launch.py")
                ),
                launch_arguments={
                    "use_sim_time": "True",
                }.items()
            )
        ]
    )

    # 4. Multi-Robot Completion Monitor Node
    monitor_node = TimerAction(
        period=15.0,
        actions=[
            Node(
                package="explore_lite",
                executable="multi_exploration_monitor.py",
                name="multi_exploration_monitor",
                output="screen",
                parameters=[{"use_sim_time": True}]
            )
        ]
    )

    # 5. Static TF publishers linking world frame to individual robot map frames
    static_tf_r1 = Node(
        package="tf2_ros",
        executable="static_transform_publisher",
        name="static_tf_world_to_r1",
        arguments=["0.0", "0.5", "0.0", "0.0", "0.0", "0.0", "world", "robot1/map"],
        parameters=[{"use_sim_time": True}],
    )

    static_tf_r2 = Node(
        package="tf2_ros",
        executable="static_transform_publisher",
        name="static_tf_world_to_r2",
        arguments=["-2.0", "-0.5", "0.0", "0.0", "0.0", "0.0", "world", "robot2/map"],
        parameters=[{"use_sim_time": True}],
    )

    # 6. Optional RViz visualization
    rviz_config = os.path.join(pkg_map_merge, "launch", "map_merge.rviz")
    rviz_cmd = Node(
        condition=IfCondition(use_rviz),
        package="rviz2",
        executable="rviz2",
        name="rviz2_merged",
        arguments=["-d", rviz_config],
        output="screen",
        parameters=[{"use_sim_time": True}]
    )

    return LaunchDescription([
        declare_simulator_cmd,
        declare_use_rviz_cmd,
        static_tf_r1,
        static_tf_r2,
        multi_tb3_sim,
        map_merge_cmd,
        dual_explore_cmd,
        monitor_node,
        rviz_cmd,
    ])
