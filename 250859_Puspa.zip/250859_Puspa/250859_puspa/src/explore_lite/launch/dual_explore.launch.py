import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_explore = get_package_share_directory("explore_lite")
    config_r1 = os.path.join(pkg_explore, "config", "params_robot1.yaml")
    config_r2 = os.path.join(pkg_explore, "config", "params_robot2.yaml")

    use_sim_time = LaunchConfiguration("use_sim_time")

    declare_use_sim_time_argument = DeclareLaunchArgument(
        "use_sim_time", default_value="true", description="Use simulation/Gazebo clock"
    )

    remappings = []

    node_r1 = Node(
        package="explore_lite",
        name="explore_node",
        namespace="robot1",
        executable="explore",
        parameters=[config_r1, {"use_sim_time": use_sim_time}],
        output="screen",
        remappings=remappings,
    )

    node_r2 = Node(
        package="explore_lite",
        name="explore_node",
        namespace="robot2",
        executable="explore",
        parameters=[config_r2, {"use_sim_time": use_sim_time}],
        output="screen",
        remappings=remappings,
    )

    return LaunchDescription([
        declare_use_sim_time_argument,
        node_r1,
        node_r2,
    ])
