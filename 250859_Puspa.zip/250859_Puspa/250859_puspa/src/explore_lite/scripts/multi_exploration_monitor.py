#!/usr/bin/env python3
import os
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy
from explore_lite_msgs.msg import ExploreStatus
from geometry_msgs.msg import Twist
from nav_msgs.msg import OccupancyGrid


class MultiExplorationMonitor(Node):
    def __init__(self):
        super().__init__('multi_exploration_monitor')

        self.get_logger().info('Starting Multi-Robot Exploration & Mapping Monitor...')

        self.r1_complete = False
        self.r2_complete = False
        self.finished = False

        self.r1_last_status = 'starting'
        self.r2_last_status = 'starting'

        # QoS for status topics (transient local)
        status_qos = QoSProfile(depth=10)
        status_qos.durability = QoSDurabilityPolicy.TRANSIENT_LOCAL
        status_qos.reliability = QoSReliabilityPolicy.RELIABLE

        self.sub_r1_status = self.create_subscription(
            ExploreStatus,
            '/robot1/explore/status',
            self.r1_status_callback,
            status_qos
        )

        self.sub_r2_status = self.create_subscription(
            ExploreStatus,
            '/robot2/explore/status',
            self.r2_status_callback,
            status_qos
        )

        self.sub_merged_map = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.merged_map_callback,
            10
        )

        self.sub_r1_map = self.create_subscription(
            OccupancyGrid,
            '/robot1/map',
            self.r1_map_callback,
            10
        )

        self.sub_r2_map = self.create_subscription(
            OccupancyGrid,
            '/robot2/map',
            self.r2_map_callback,
            10
        )

        # Stop command publishers
        self.pub_r1_cmd = self.create_publisher(Twist, '/robot1/cmd_vel', 10)
        self.pub_r2_cmd = self.create_publisher(Twist, '/robot2/cmd_vel', 10)

        # Periodic check timer
        self.timer = self.create_timer(1.0, self.check_completion)
        self.merged_map_received = False
        self.map_info_str = ''
        self.merged_map_msg = None
        self.r1_map_msg = None
        self.r2_map_msg = None
        self.maps_saved = False

    def r1_status_callback(self, msg: ExploreStatus):
        self.r1_last_status = msg.status
        self.get_logger().info(f'[Robot 1 Status Update]: {msg.status}')
        if msg.status in [ExploreStatus.EXPLORATION_COMPLETE, ExploreStatus.RETURNED_TO_ORIGIN]:
            self.r1_complete = True
            self.stop_robot(self.pub_r1_cmd)

    def r2_status_callback(self, msg: ExploreStatus):
        self.r2_last_status = msg.status
        self.get_logger().info(f'[Robot 2 Status Update]: {msg.status}')
        if msg.status in [ExploreStatus.EXPLORATION_COMPLETE, ExploreStatus.RETURNED_TO_ORIGIN]:
            self.r2_complete = True
            self.stop_robot(self.pub_r2_cmd)

    def merged_map_callback(self, msg: OccupancyGrid):
        self.merged_map_received = True
        self.merged_map_msg = msg
        self.map_info_str = f'{msg.info.width}x{msg.info.height} cells @ {msg.info.resolution:.2f}m/cell'

    def r1_map_callback(self, msg: OccupancyGrid):
        self.r1_map_msg = msg

    def r2_map_callback(self, msg: OccupancyGrid):
        self.r2_map_msg = msg

    def save_map(self, grid_msg, base_path):
        if grid_msg is None:
            return False
        try:
            os.makedirs(os.path.dirname(os.path.abspath(base_path)), exist_ok=True)
            width = grid_msg.info.width
            height = grid_msg.info.height
            res = grid_msg.info.resolution
            ox = grid_msg.info.origin.position.x
            oy = grid_msg.info.origin.position.y
            data = grid_msg.data

            pgm_path = f"{base_path}.pgm"
            with open(pgm_path, "wb") as f:
                f.write(f"P5\n{width} {height}\n255\n".encode("ascii"))
                img_bytes = bytearray(width * height)
                for r in range(height):
                    src_row = (height - 1 - r) * width
                    dst_row = r * width
                    for c in range(width):
                        val = data[src_row + c]
                        if val == -1:
                            pixel = 205
                        elif val <= 20:
                            pixel = 254
                        elif val >= 65:
                            pixel = 0
                        else:
                            pixel = int(255 - (val * 255 / 100))
                        img_bytes[dst_row + c] = pixel
                f.write(img_bytes)

            yaml_path = f"{base_path}.yaml"
            with open(yaml_path, "w") as f:
                f.write(f"image: {os.path.basename(pgm_path)}\n")
                f.write(f"mode: trinary\n")
                f.write(f"resolution: {res}\n")
                f.write(f"origin: [{ox}, {oy}, 0.0]\n")
                f.write(f"negate: 0\n")
                f.write(f"occupied_thresh: 0.65\n")
                f.write(f"free_thresh: 0.25\n")
            return True
        except Exception as e:
            self.get_logger().error(f"Failed to save map {base_path}: {e}")
            return False

    def stop_robot(self, publisher):
        stop_msg = Twist()
        stop_msg.linear.x = 0.0
        stop_msg.linear.y = 0.0
        stop_msg.linear.z = 0.0
        stop_msg.angular.x = 0.0
        stop_msg.angular.y = 0.0
        stop_msg.angular.z = 0.0
        for _ in range(5):
            publisher.publish(stop_msg)

    def check_completion(self):
        if self.finished:
            # Keep sending stop commands to ensure robots stay stationary
            self.stop_robot(self.pub_r1_cmd)
            self.stop_robot(self.pub_r2_cmd)
            return

        if self.r1_complete and self.r2_complete and not self.finished:
            self.finished = True
            self.stop_robot(self.pub_r1_cmd)
            self.stop_robot(self.pub_r2_cmd)

            # Save generated SLAM and merged maps to disk
            save_dir = os.environ.get("MAP_SAVE_DIR", os.path.join(os.getcwd(), "maps"))
            os.makedirs(save_dir, exist_ok=True)
            self.save_map(self.merged_map_msg, os.path.join(save_dir, "merged_map"))
            self.save_map(self.r1_map_msg, os.path.join(save_dir, "robot1_map"))
            self.save_map(self.r2_map_msg, os.path.join(save_dir, "robot2_map"))

            banner = (
                "\n"
                "╔══════════════════════════════════════════════════════════════════════════════╗\n"
                "║                                                                              ║\n"
                "║           🎉 ALL TASKS COMPLETE: MULTI-ROBOT MAPPING FINISHED! 🎉            ║\n"
                "║                                                                              ║\n"
                "║  ✓ Both Robot 1 and Robot 2 have explored and mapped simultaneously.         ║\n"
                "║  ✓ SLAM mapping and multi-robot map merging active throughout simulation.    ║\n"
                "║  ✓ No more unexplored frontiers remain in the arena.                         ║\n"
                "║  ✓ Both robots have safely stopped moving.                                   ║\n"
                f"║  ✓ Merged global map published on /map ({self.map_info_str}){' '*(42 - len(self.map_info_str))}║\n"
                f"║  ✓ Maps saved to: {save_dir:<58} ║\n"
                "║    - merged_map.yaml & merged_map.pgm                                        ║\n"
                "║    - robot1_map.yaml & robot1_map.pgm                                        ║\n"
                "║    - robot2_map.yaml & robot2_map.pgm                                        ║\n"
                "║                                                                              ║\n"
                "╚══════════════════════════════════════════════════════════════════════════════╝\n"
            )
            print(banner, flush=True)
            self.get_logger().info('EXPLORATION AND MAPPING COMPLETED FOR BOTH ROBOTS. ALL ROBOTS STOPPED.')


def main(args=None):
    rclpy.init(args=args)
    node = MultiExplorationMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
